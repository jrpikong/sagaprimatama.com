<?php $__env->startSection('content'); ?>
  <section class="jumbotron demo-custom-height-1 full-width" data-pages-bg-image="<?php echo e(asset('storage/'.$aboutPage->image)); ?>" data-pages="parallax" data-bg-overlay="black" data-overlay-opacity="0.4" style="background-image: url(<?php echo e(asset('storage/'.$aboutPage->image)); ?>); background-position: center 46.1538%;">
    <div class="inner full-height" style="transform: translateY(0px);">
      <div class="container-xs-height full-height">
        <div class="col-xs-height col-middle text-left">
          <div class="container">
            <div class="col-sm-6 col-sm-offset-3 sm-m-t-30 sm-p-t-20 sm-p-b-20">
              <h1 class="light text-center text-white xs-p-t-30 sm-p-b-30">
                Digital solutions led by clarity, simplicity &amp; honesty
              </h1>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="bg-overlay" style="background-color: black; opacity: 0.4;"></div>
  </section>

  <section class="bg-master-lightest p-b-60 p-t-60">
    <div class="container">
      <div class="md-p-l-20 md-p-r-20 xs-no-padding">
        <h5 class="block-title hint-text no-margin"><?php echo e($aboutPage->title); ?></h5>
        <div class="row">
          <div class="col-sm-5 col-md-4">
            <h1 class="m-t-5">"<?php echo e($aboutPage->excerpt); ?>"</h1>
          </div>
          <div class="col-sm-7 col-md-8 no-padding xs-p-l-15 xs-p-r-15">
            <div class="p-t-20 p-l-35 md-p-l-5 md-p-t-15">
              <p><?php echo $aboutPage->body; ?></p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <?php echo $__env->make('patilas.services', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
  <script type="text/javascript" src="<?php echo e(asset('/plugins/animateNumber/jquery.animateNumbers.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>